package conexion.sql;

public class ConectorSQL {

    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    public static final String DB_URL = "jdbc:mysql://localhost:3306/prode";

    // Credenciales credentials
    public static final String USER = "root";
    public static final String PASS = "root";

}
